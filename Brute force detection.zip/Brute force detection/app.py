import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
from dotenv import load_dotenv # type: ignore
import logging

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("APP_SECRET_KEY", "secure_key")

# Simulated database
users = {
    'admin': 'admin123',
    'user1': 'password123'
}

# Suspicious usernames
SUSPICIOUS_USERNAMES = ['root', 'admin123', 'test', 'hacker']

# Failed attempts tracker
failed_attempts = {}
SUSPICIOUS_THRESHOLD = 5  # Updated from 3 to 5

# Log file
LOG_FILE = "login_attempts.log"  # Changed path to current directory for easier access

# Logging config
logging.basicConfig(level=logging.INFO)

# Log login attempts locally
def log_attempt(username, status):
    with open(LOG_FILE, 'a') as log:
        log.write(f"{datetime.now()} | Username: {username} | Status: {status}\n")
    logging.info(f"{datetime.now()} | Username: {username} | Status: {status}")

# Home page
@app.route('/')
def index():
    return render_template('index.html')

# Login
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    # Check if user is suspicious or has crossed threshold
    if username in SUSPICIOUS_USERNAMES or failed_attempts.get(username, 0) >= SUSPICIOUS_THRESHOLD:
        log_attempt(username, "Suspicious")
        flash("Suspicious activity detected or too many failed attempts. Access denied.", 'error')
        return redirect(url_for('index'))

    # Check valid credentials
    if username in users and users[username] == password:
        session['username'] = username
        failed_attempts[username] = 0  # Reset count
        log_attempt(username, "Success")
        return redirect(url_for('dashboard'))

    # Failed login
    failed_attempts[username] = failed_attempts.get(username, 0) + 1
    if failed_attempts[username] >= SUSPICIOUS_THRESHOLD:
        log_attempt(username, "Suspicious")
        flash("Suspicious activity detected after multiple failed attempts.", 'error')
    else:
        log_attempt(username, "Failed")
        flash(f"Invalid credentials. Attempt {failed_attempts[username]}/{SUSPICIOUS_THRESHOLD}.", 'error')

    return redirect(url_for('index'))

# Dashboard
@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'])
    else:
        flash("Please log in first.", 'error')
        return redirect(url_for('index'))

# Create new user
@app.route('/create_user', methods=['GET', 'POST'])
def create_user():
    if request.method == 'POST':
        new_username = request.form['new_username']
        new_password = request.form['new_password']

        if new_username in users:
            flash("Username already exists. Choose a different one.", 'error')
        else:
            users[new_username] = new_password
            flash("User created successfully!", 'success')
        return redirect(url_for('index'))

    return render_template('create_user.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("You have successfully logged out.", 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
